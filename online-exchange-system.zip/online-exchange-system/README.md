# online-exchange-system
course project s.2

POST API REQUEST EXAMPLE:
  ```
    {
      "login": "testAPI2222",
      "password": "testAPI123!",
      "email": "apitest@ex.com",
      "balance": 222.10,
      "active": true,
      "roles": [ "USER", "ADMIN", "MODERATOR" ],
      "goods": [],
      "buys": [],
      "requestTSCollection": [],
      "requestMRGCollection": []
    }
  ```
