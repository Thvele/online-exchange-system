package com.funpaycopy.oes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineExchangeSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineExchangeSystemApplication.class, args);
	}

}
