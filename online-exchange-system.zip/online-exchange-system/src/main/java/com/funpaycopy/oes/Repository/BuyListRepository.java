package com.funpaycopy.oes.Repository;

import com.funpaycopy.oes.Model.BuyList;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BuyListRepository extends JpaRepository<BuyList, Long> {


}
