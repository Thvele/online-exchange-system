package com.funpaycopy.oes.Repository;

import com.funpaycopy.oes.Model.GoodsList;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GoodsListRepository extends JpaRepository<GoodsList, Long> {


}
