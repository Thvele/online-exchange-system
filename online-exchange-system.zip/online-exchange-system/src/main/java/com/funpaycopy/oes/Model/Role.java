package com.funpaycopy.oes.Model;


public enum Role {

    USER, SELLER, ADMIN, MODERATOR
}
